function openPerson(id, group){
  window.location.href=("http://wishlist1.1234567890hihi.repl.co/person/"+group+"/"+id)
}

function goBack(){
  window.location.href = "http://wishlist1.1234567890hihi.repl.co/groups"
}